The following three R scripts can be used to reproduce the 
computations reported in our paper:

1)	Durbin MA(1) efficiency:  wsDurbin.R
2)	Timings for fitting ARMA model:  wsTiming.R
3)	Obtain the sample mean efficiency: wsMean.R RunAll.R