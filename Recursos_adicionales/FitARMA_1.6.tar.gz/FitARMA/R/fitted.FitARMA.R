"fitted.FitARMA" <-
function (object, ...) 
{
    object$fits
}
