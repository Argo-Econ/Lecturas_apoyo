"residuals.FitARMA" <-
function (object, ...) 
{
    object$res
}
