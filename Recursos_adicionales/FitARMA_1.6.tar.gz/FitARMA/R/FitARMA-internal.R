".onLoad" <-
function(lib, pkg) library.dynam("FitARMA", pkg, lib)

